package com.rms.bank.management.system.entity;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW
}
