package com.rms.bank.management.system.mapper;

import com.rms.bank.management.system.entity.Account;
import com.rms.bank.management.system.model.account.AccountResponseModel;

public interface AccountMapper {
    AccountResponseModel toResponseModel(Account account);
}
