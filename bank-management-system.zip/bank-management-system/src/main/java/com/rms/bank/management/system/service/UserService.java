package com.rms.bank.management.system.service;

import com.rms.bank.management.system.model.authentication.UserProfileResponseModel;

public interface UserService {
    UserProfileResponseModel getUserProfile();
}
