package com.rms.bank.management.system.mapper;

import com.rms.bank.management.system.entity.User;
import com.rms.bank.management.system.model.authentication.UserProfileResponseModel;

public interface UserProfileMapper {
    UserProfileResponseModel toUserProfile(User user);
}
