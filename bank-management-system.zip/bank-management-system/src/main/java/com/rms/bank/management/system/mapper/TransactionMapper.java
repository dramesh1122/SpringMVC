package com.rms.bank.management.system.mapper;

import com.rms.bank.management.system.entity.Account;
import com.rms.bank.management.system.entity.Transaction;
import com.rms.bank.management.system.entity.TransactionType;
import com.rms.bank.management.system.model.transaction.DepositRequestModel;
import com.rms.bank.management.system.model.transaction.TransactionResponseModel;

public interface TransactionMapper {
    Transaction toEntity(double amount, Account account, TransactionType type);
    TransactionResponseModel toResponseModel(Long id, double amount, double balance);
}
