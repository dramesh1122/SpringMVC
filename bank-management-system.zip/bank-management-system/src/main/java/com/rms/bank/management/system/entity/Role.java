package com.rms.bank.management.system.entity;

public enum Role {
    USER,
    ADMIN
}
