package com.rms.bank.management.system.mapper;

import com.rms.bank.management.system.entity.User;
import com.rms.bank.management.system.model.authentication.RegisterRequestModel;

public interface UserMapper {
    User toUser(RegisterRequestModel request);
}
