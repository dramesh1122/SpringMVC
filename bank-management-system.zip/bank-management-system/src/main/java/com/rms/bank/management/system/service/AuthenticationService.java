package com.rms.bank.management.system.service;

import com.rms.bank.management.system.model.authentication.AuthenticationResponseModel;
import com.rms.bank.management.system.model.authentication.RegisterRequestModel;
import com.rms.bank.management.system.model.authentication.LoginRequestModel;
import com.rms.bank.management.system.model.authentication.UserProfileResponseModel;

public interface AuthenticationService {
    public AuthenticationResponseModel register(RegisterRequestModel request);

    public AuthenticationResponseModel login(LoginRequestModel request);
}
